#!/usr/bin/env python3
"""Static boundary audit. Not a security certification."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r"requests\.","network"),(r"urllib\.request","network"),(r"socket\.","socket"),(r"eval\(","dynamic eval"),(r"exec\(","dynamic exec"),(r"os\.system","shell"),(r"camera|microphone|getUserMedia","media capture"),(r"prescribe|diagnose","dangerous medical claim string")]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json','README.md','GOVERNANCE.md','SOURCES.md'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.html','.js','.py','.json'}: continue
        txt=p.read_text(encoding='utf-8',errors='ignore')
        for pat,meaning in PATTERNS:
            if re.search(pat,txt,re.I): findings.append({'file':str(p.relative_to(ROOT)),'pattern':pat,'meaning':meaning})
    result={'package':'DIKWP Cardiac TriageCare RehabOS 2026 V1','findings':findings,'no_network_or_media_or_prescribing_adapter':not bool(findings),'note':'String matches require human review; this is not a security certification.'}
    out=ROOT/'static_boundary_audit_report.json'
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
