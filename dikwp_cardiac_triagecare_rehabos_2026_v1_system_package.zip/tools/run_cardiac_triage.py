#!/usr/bin/env python3
"""Offline CLI for DIKWP Cardiac TriageCare RehabOS.
Synthetic/de-identified cases only. No diagnosis or prescription.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime, timezone

def infer_level(case:dict)->str:
    text=' '.join([case.get('name',''),case.get('profile',''),' '.join(case.get('signals',[]))])
    red=['持续胸痛','胸痛30','大汗','晕厥','撕裂','心脏骤停','严重呼吸困难','休克']
    if any(x in text for x in red): return 'C5'
    if '夜间憋醒' in text or '近晕厥' in text or '220/120' in text: return 'C4'
    return case.get('default','C2')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('case',type=Path)
    ap.add_argument('--out',type=Path,default=Path('outputs'))
    args=ap.parse_args()
    case=json.loads(args.case.read_text(encoding='utf-8'))
    level=infer_level(case)
    passport={
      'version':'DIKWP Cardiac TriageCare RehabOS 2026 V1 CLI',
      'generated_at':datetime.now(timezone.utc).isoformat(),
      'synthetic':True,
      'case_id':case.get('id'),
      'triage_level':level,
      'actions':['Emergency services / clinical review required' if level in {'C4','C5'} else 'Prepare clinical visit and evidence ledger'],
      'boundaries':{'diagnosis':False,'prescription':False,'emergency_replacement':False,'human_clinical_review_required':True}
    }
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/f"{case.get('id','case')}_cardiac_care_passport.json"
    target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP Cardiac TriageCare RehabOS')
    print('='*68)
    print('Case:',case.get('name'))
    print('Action level:',level)
    print('Output:',target)
    print('Boundary: no diagnosis, no prescription, no emergency replacement.')
if __name__=='__main__': main()
