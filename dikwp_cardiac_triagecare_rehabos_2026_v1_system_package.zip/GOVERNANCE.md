# Governance and Safety Boundary

## Human clinical review
Every non-educational output must be reviewed by an appropriate human clinical role: EMS, emergency department, chest pain center, cardiologist, primary care clinician, pharmacist, or cardiac rehabilitation team.

## Emergency rule
If red flags are present, stop chatbot-style analysis and direct the person to emergency services. The system may only organize handoff information.

## Party rights and privacy
- data minimization
- informed use
- no secret monitoring
- no real patient images, ECGs, or identifiers in the open prototype
- patient and family can correct symptom timelines and medication lists

## Kill conditions
Stop or downgrade the workflow if:
- acute chest pain or severe dyspnea is present
- suspected cardiac arrest, syncope, shock, tearing chest/back pain, or high-risk arrhythmia signs occur
- AI tries to prescribe, diagnose, decide intervention, or change medication
- ECG/troponin/clinical evaluation is required but missing
- medication adherence is uncertain in a high-risk disease
- rehabilitation load is not clinically assessed
- real patient data are not authorized or de-identified
