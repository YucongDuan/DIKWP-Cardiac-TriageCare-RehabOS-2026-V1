# 30-Day Pilot Plan

## Week 1: Governance and safety boundaries
- define emergency escalation, 120/EMS routing, privacy, red flags, prohibited outputs, and clinical roles
- use synthetic or de-identified cases only
- configure C0-C5 action-level triage and review workflow

## Week 2: Evidence ledger and triage rehearsal
- enter 10-20 synthetic or de-identified scenarios: chest pain, heart failure, palpitations, hypertension, post-PCI rehab, prevention
- generate Care Evidence Ledgers and Action Tickets
- test missing ECG/troponin, conflicting reports, and AI overreach

## Week 3: treatment coordination and rehabilitation
- build clinician-reviewed care coordination templates
- build cardiac rehab five-prescription templates
- test home monitoring and medication-adherence workflows

## Week 4: audit and review
- run static boundary audit
- review outputs with EMS/emergency/cardiology/rehab/pharmacy roles
- export Cardiac Care Passports
- revise kill conditions and deploy only as decision-support preparation

## Acceptance criteria
- zero diagnosis/prescription outputs
- red flags escalate to C4/C5
- all tickets have human owner
- critical evidence gaps are marked residual
- rehabilitation plan requires assessment
- AI Use Log records purpose and human verification
