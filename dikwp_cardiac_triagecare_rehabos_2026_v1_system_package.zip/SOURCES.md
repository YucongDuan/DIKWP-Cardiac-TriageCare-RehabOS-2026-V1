# Sources and Reference Principles

- WHO cardiovascular diseases fact sheet, 2025.
- American Heart Association warning signs of heart attack, updated 2024/2025.
- CDC heart disease and heart attack symptom information, 2024.
- 2021 AHA/ACC Chest Pain Guideline and slide set.
- 2025 ACC/AHA/ACEP/NAEMSP/SCAI Guideline for Acute Coronary Syndromes.
- 2023 ACC/AHA Chronic Coronary Disease guideline.
- 2022 AHA/ACC/HFSA Heart Failure guideline.
- 2023 ACC/AHA/ACCP/HRS Atrial Fibrillation guideline.
- 2024 ESC Chronic Coronary Syndromes guideline.
- Chinese Chest Pain Center certification standards and acute chest pain expert consensus.
- Chinese cardiac rehabilitation guidelines and expert consensus, including five core prescriptions.

All sources must be re-verified for jurisdiction, date, and local clinical pathway before deployment.
