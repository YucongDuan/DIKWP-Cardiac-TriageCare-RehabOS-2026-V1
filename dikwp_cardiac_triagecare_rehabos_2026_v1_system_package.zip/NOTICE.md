# NOTICE

DIKWP Cardiac TriageCare RehabOS 2026 V1 is a reference prototype for education, triage preparation, care coordination, rehabilitation planning support, and governance discussion. It is not a medical device, diagnostic tool, emergency response service, prescription system, or clinical decision authority. All cases are synthetic.

Attribution: Yucong Duan / DIKWP ecosystem reference implementation.
